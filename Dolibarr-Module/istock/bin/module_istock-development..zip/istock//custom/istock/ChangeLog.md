# CHANGELOG iSTOCK pour Dolibarr

## 1.0

En développement...
<!-- Initial version -->
